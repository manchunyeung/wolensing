__author__ = 'Mark Ho Yeuk Cheung, Simon Man Chun Yeung'
__email__ = 'yeungm@uwm.edu'
__credits__ = 'JHU, UWM'
